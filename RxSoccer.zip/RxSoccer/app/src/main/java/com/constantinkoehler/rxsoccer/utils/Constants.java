package com.constantinkoehler.rxsoccer.utils;

public class Constants {
    public static final String gameURL = "https://webhooks.mongodb-stitch.com/api/client/v2.0/app/soccerapi-vfdog/service/WebHooks/incoming_webhook/getSampleData";
}
